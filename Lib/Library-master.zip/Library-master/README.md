# C++ Library

C++ Library

- lodepng: Library for load PNG image
- loadpng: Use lodepng to load image, add Swap_Image func to reverse Image
- process_image: Define Image, Process Image Function: Create, Delete, Clone, Rotate, Mix...
- gl_texture: Define Rect, Load, Map and Draw texture in OpenGL

- import in code as a part of your program (gl_texture need import glut(freeglut) and process_image first)